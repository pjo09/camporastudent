// =====================================================
// CAMPORA ADD / EDIT PROPERTY PAGE
// Uses existing APIs only (no new endpoints)
// 1. POST /api/properties/create (images + basic fields)
// 2. PUT  /api/owner/properties/:id  (remaining fields)
// =====================================================

import { getToken, getUser, protectPageByRole } from "./session.js";
import { API } from "./config.js";

const API_BASE = `${API}/api`;

// =====================================================
// AUTH
// =====================================================

const user = protectPageByRole(["owner"]);
const token = getToken();
if (!user || !token) {}

const $ = (id) => document.getElementById(id);

const DOM = {
  name: $("addPropName"),
  avatar: $("addPropAvatar"),
  toastContainer: $("toastContainer"),
  submitOverlay: $("submitOverlay"),
  submitIcon: $("submitIcon"),
  submitTitle: $("submitTitle"),
  submitDesc: $("submitDesc"),
  publishBtn: $("publishBtn"),
  saveDraftBtn: $("saveDraftBtn"),
  cancelBtn: $("cancelBtn"),
  imageUploadArea: $("imageUploadArea"),
  imageInput: $("imageInput"),
  imagePreviewGrid: $("imagePreviewGrid"),
  imageError: $("imageError"),
  uploadProgress: $("uploadProgress"),
  progressFill: $("progressFill"),
  progressText: $("progressText"),
  descCount: $("descCount"),
  // Elements referenced by init()/setupEventListeners() that were missing:
  form: $("propertyForm"),
  pageTitle: $("pageTitle"),
  editBanner: $("editBanner"),
  loading: $("formLoading"),
};

// Fields with validation groups
const FIELDS = [
  "propName", "propType", "description",
  "address", "city", "state",
  "rent", "deposit",
  "sharing", "gender", "totalBeds", "availableBeds",
];

// =====================================================
// STATE
// =====================================================

const state = {
  uploadedImages: [],
  editPropertyId: null, // set if editing
  isSubmitting: false,
};

// =====================================================
// INIT
// =====================================================

init();

async function init() {
  renderOwnerInfo();
  setupEventListeners();

  // Check if editing (URL param ?id=xxx)
  const params = new URLSearchParams(window.location.search);
  const editId = params.get("id");
  if (editId) {
    state.editPropertyId = editId;
    DOM.pageTitle.textContent = "Edit Property";
    DOM.editBanner.style.display = "block";
    await loadPropertyForEdit(editId);
  }

  DOM.loading.style.display = "none";
}

// =====================================================
// OWNER INFO
// =====================================================

function renderOwnerInfo() {
  if (!user) return;
  DOM.name.textContent = user.name || "Owner";
  DOM.avatar.textContent = (user.name || "O").charAt(0).toUpperCase();
}

// =====================================================
// LOAD PROPERTY FOR EDITING
// =====================================================

async function loadPropertyForEdit(id) {
  try {
    const res = await fetch(`${API_BASE}/owner/properties/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.message || "Property not found");

    const p = data.property || {};
    populateForm(p);
  } catch (err) {
    console.error("Edit load error:", err);
    showToast("Failed to load property for editing", "error");
  }
}

function populateForm(p) {
  if (!$("propName")) return;
  $("propName").value = p.propertyName || "";
  $("propType").value = p.propertyType || "";
  $("description").value = p.description || "";
  $("address").value = p.address || "";
  $("city").value = p.city || "";
  $("state").value = p.state || "";
  $("college").value = p.college || "";
  $("latitude").value = p.latitude || "";
  $("longitude").value = p.longitude || "";
  $("rent").value = p.rent || "";
  $("deposit").value = p.deposit || "";
  $("maintenance").value = p.maintenanceCharge || "";
  $("sharing").value = p.sharing || "";
  $("gender").value = p.gender || "";
  $("totalBeds").value = p.totalBeds || "";
  $("availableBeds").value = p.availableBeds || "";

  // Amenities
  const amenities = (p.amenities || []).map((a) => a.toLowerCase());
  document.querySelectorAll("#amenitiesGrid input[type=checkbox]").forEach((cb) => {
    cb.checked = amenities.includes(cb.value.toLowerCase());
  });

  // House rules
  const rules = p.houseRules || {};
  if (document.getElementById("ruleSmoking")) document.getElementById("ruleSmoking").checked = rules.smoking || false;
  if (document.getElementById("ruleDrinking")) document.getElementById("ruleDrinking").checked = rules.drinking || false;
  if (document.getElementById("rulePets")) document.getElementById("rulePets").checked = rules.pets || false;
  if (document.getElementById("ruleVisitors")) document.getElementById("ruleVisitors").checked = rules.visitors !== false;

  // Images
  if (p.images && p.images.length) {
    state.uploadedImages = p.images.map((img) => ({
      url: img.startsWith("http") ? img : `${API}/uploads/${img.replace(/^\//, "")}`,
      existing: true,
      filename: img,
    }));
    renderImagePreviews();
  }
}

// =====================================================
// EVENT LISTENERS
// =====================================================

function setupEventListeners() {
  // Image upload
  DOM.imageInput?.addEventListener("change", handleImageSelect);
  DOM.imageUploadArea?.addEventListener("dragover", (e) => { e.preventDefault(); DOM.imageUploadArea.style.borderColor = "#2563eb"; });
  DOM.imageUploadArea?.addEventListener("dragleave", () => { DOM.imageUploadArea.style.borderColor = "rgba(255,255,255,.12)"; });
  DOM.imageUploadArea?.addEventListener("drop", (e) => { e.preventDefault(); DOM.imageUploadArea.style.borderColor = "rgba(255,255,255,.12)"; if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); });

  // Description char count
  $("description")?.addEventListener("input", () => {
    DOM.descCount.textContent = $("description").value.length;
  });

  // Submit
  DOM.form?.addEventListener("submit", handleSubmit);

  // Save draft
  DOM.saveDraftBtn?.addEventListener("click", () => handleSubmit(null, true));

  // Cancel
  DOM.cancelBtn?.addEventListener("click", () => {
    if (confirm("Discard changes and go back?")) window.location.href = "owner-dashboard.html";
  });

  // Enter key for textareas should not submit
  $("description")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) e.preventDefault();
  });
}

// =====================================================
// IMAGE HANDLING
// =====================================================

function handleImageSelect(e) {
  handleFiles(e.target.files);
}

function handleFiles(files) {
  const remaining = 10 - state.uploadedImages.length;
  if (files.length > remaining) {
    showToast(`You can only upload ${remaining} more image(s)`, "error");
    return;
  }

  Array.from(files).forEach((file) => {
    if (!["image/jpeg", "image/jpg", "image/png", "image/webp"].includes(file.type)) {
      showToast(`${file.name} is not a supported format`, "error");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      showToast(`${file.name} exceeds 10MB limit`, "error");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      state.uploadedImages.push({ url: e.target.result, file: file, existing: false });
      renderImagePreviews();
    };
    reader.readAsDataURL(file);
  });

  DOM.imageInput.value = "";
}

function renderImagePreviews() {
  DOM.imagePreviewGrid.innerHTML = "";
  state.uploadedImages.forEach((img, i) => {
    const div = document.createElement("div");
    div.className = "image-preview-item";
    div.innerHTML = `
      <img src="${img.url}" alt="Property image ${i + 1}" loading="lazy" />
      <button type="button" class="remove-img" data-index="${i}" aria-label="Remove image"><i class="fa-solid fa-xmark"></i></button>`;
    div.querySelector(".remove-img").addEventListener("click", () => {
      state.uploadedImages.splice(i, 1);
      renderImagePreviews();
    });
    DOM.imagePreviewGrid.appendChild(div);
  });
  DOM.imageError.style.display = state.uploadedImages.length === 0 ? "block" : "none";
}

// =====================================================
// VALIDATION
// =====================================================

function validateForm() {
  let valid = true;

  // Clear previous errors
  document.querySelectorAll(".form-group").forEach((g) => g.classList.remove("invalid"));

  // Property name
  if (!getVal("propName")) { markInvalid("fg-propName"); valid = false; }

  // Property type
  if (!getVal("propType")) { markInvalid("fg-propType"); valid = false; }

  // Description
  const desc = getVal("description");
  if (!desc || desc.length < 20) { markInvalid("fg-description"); valid = false; }

  // Address
  if (!getVal("address")) { markInvalid("fg-address"); valid = false; }

  // City
  if (!getVal("city")) { markInvalid("fg-city"); valid = false; }

  // State
  if (!getVal("state")) { markInvalid("fg-state"); valid = false; }

  // Rent
  const rent = parseInt(getVal("rent")) || 0;
  if (rent <= 0) { markInvalid("fg-rent"); valid = false; }

  // Deposit
  const deposit = parseInt(getVal("deposit"));
  if (deposit < 0 || isNaN(deposit)) { markInvalid("fg-deposit"); valid = false; }

  // Sharing
  if (!getVal("sharing")) { markInvalid("fg-sharing"); valid = false; }

  // Gender
  if (!getVal("gender")) { markInvalid("fg-gender"); valid = false; }

  // Total beds
  const totalBeds = parseInt(getVal("totalBeds")) || 0;
  if (totalBeds < 1) { markInvalid("fg-totalBeds"); valid = false; }

  // Available beds
  const availBeds = parseInt(getVal("availableBeds"));
  if (availBeds < 0 || isNaN(availBeds)) { markInvalid("fg-availableBeds"); valid = false; }

  // At least one image
  if (state.uploadedImages.length === 0 && !state.editPropertyId) {
    DOM.imageError.style.display = "block";
    valid = false;
  } else {
    DOM.imageError.style.display = "none";
  }

  if (!valid) {
    // Scroll to first error
    const firstInvalid = document.querySelector(".form-group.invalid");
    if (firstInvalid) firstInvalid.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  return valid;
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : "";
}

function markInvalid(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add("invalid");
}

// =====================================================
// SUBMIT
// =====================================================

async function handleSubmit(e, isDraft = false) {
  if (e) e.preventDefault();
  if (state.isSubmitting) return;

  if (!validateForm()) return;

  state.isSubmitting = true;
  showOverlay(isDraft ? "Saving Draft..." : "Publishing Property...", "Please wait...");

  try {
    let propertyId = state.editPropertyId;

    // ===== STEP 1: Upload new images only where the create/update endpoint
    //               does NOT already perform multipart upload.
    //               CREATE -> /api/properties/create uses multer itself,
    //               so images must NOT be pre-uploaded (avoids 2x uploads).
    //               EDIT   -> /api/properties/:id is JSON-only, so new files
    //               must be uploaded via /api/upload first.
    // =====
    const newFiles = state.uploadedImages.filter((img) => !img.existing);
    const existingImages = state.uploadedImages.filter((img) => img.existing);
    const isEditMode = !!state.editPropertyId;

    let uploadedImageUrls = [];

    if (isEditMode && newFiles.length > 0) {
      const formData = new FormData();
      newFiles.forEach((img) => formData.append("images", img.file));

      const uploadRes = await fetch(`${API_BASE}/upload`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const uploadData = await uploadRes.json();
      if (!uploadData.success) throw new Error(uploadData.message || "Image upload failed");

      uploadedImageUrls = uploadData.images.map((img) => img.url);
    }

    // Combine existing + new image URLs
    const allImageUrls = [
      ...existingImages.map((img) => (img.filename ? img.filename : img.url)),
      ...uploadedImageUrls,
    ];

    if (propertyId) {
      // ===== EDIT MODE: PUT /api/properties/:id (general route - accepts all fields) =====
      const body = buildPropertyBody(allImageUrls, isDraft);
      const res = await fetch(`${API_BASE}/properties/${propertyId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message || "Update failed");
    } else {
      // ===== CREATE MODE: POST /api/properties/create =====
      // Use FormData for multer image upload — do NOT send amenities as JSON string
      // (multer parses it as a string, not an array, breaking the [String] schema)
      const formData = new FormData();
      state.uploadedImages.forEach((img) => {
        if (img.file) formData.append("images", img.file);
      });
      formData.append("propertyName", getVal("propName"));
      formData.append("propertyType", getVal("propType"));
      formData.append("description", getVal("description"));
      formData.append("address", getVal("address"));
      formData.append("city", getVal("city"));
      formData.append("state", getVal("state"));
      if (getVal("college")) formData.append("college", getVal("college"));
      formData.append("rent", getVal("rent"));
      formData.append("deposit", getVal("deposit") || "0");
      formData.append("sharing", getVal("sharing"));
      formData.append("gender", getVal("gender"));
      if (getVal("latitude")) formData.append("latitude", getVal("latitude"));
      if (getVal("longitude")) formData.append("longitude", getVal("longitude"));

      const createRes = await fetch(`${API_BASE}/properties/create`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const createData = await createRes.json();
      if (!createData.success) throw new Error(createData.message || "Property creation failed");

      propertyId = createData.property?._id || createData.property?.id;
    }

    // ===== STEP 2: Update extra fields via PUT /api/owner/properties/:id =====
    // (owner PUT allows: totalBeds, availableBeds, maintenanceCharge, amenities, houseRules, etc.)
    if (propertyId) {
      const extraBody = {
        totalBeds: parseInt(getVal("totalBeds")) || 0,
        availableBeds: parseInt(getVal("availableBeds")) || 0,
        maintenanceCharge: parseInt(getVal("maintenance")) || 0,
        amenities: getCheckedAmenities(),
        houseRules: {
          smoking: document.getElementById("ruleSmoking")?.checked || false,
          drinking: document.getElementById("ruleDrinking")?.checked || false,
          pets: document.getElementById("rulePets")?.checked || false,
          visitors: document.getElementById("ruleVisitors")?.checked !== false,
        },
      };

      await fetch(`${API_BASE}/owner/properties/${propertyId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(extraBody),
      });
    }

    // ===== SUCCESS =====
    showOverlaySuccess(state.editPropertyId ? "Property Updated!" : "Property Published!");

    setTimeout(() => {
      window.location.href = "owner-dashboard.html";
    }, 2000);
  } catch (err) {
    console.error("Submit error:", err);
    hideOverlay();
    showToast(err.message || "Failed to save property", "error");
  } finally {
    state.isSubmitting = false;
  }
}

// =====================================================
// BUILD PROPERTY BODY (for PUT updates)
// =====================================================

function buildPropertyBody(images, isDraft) {
  const body = {
    propertyName: getVal("propName"),
    propertyType: getVal("propType"),
    description: getVal("description"),
    address: getVal("address"),
    city: getVal("city"),
    state: getVal("state"),
    college: getVal("college") || "",
    rent: parseInt(getVal("rent")) || 0,
    deposit: parseInt(getVal("deposit")) || 0,
    sharing: getVal("sharing"),
    gender: getVal("gender"),
    totalBeds: parseInt(getVal("totalBeds")) || 0,
    availableBeds: parseInt(getVal("availableBeds")) || 0,
    maintenanceCharge: parseInt(getVal("maintenance")) || 0,
    latitude: parseFloat(getVal("latitude")) || undefined,
    longitude: parseFloat(getVal("longitude")) || undefined,
    houseRules: {
      smoking: document.getElementById("ruleSmoking")?.checked || false,
      drinking: document.getElementById("ruleDrinking")?.checked || false,
      pets: document.getElementById("rulePets")?.checked || false,
      visitors: document.getElementById("ruleVisitors")?.checked !== false,
    },
    amenities: getCheckedAmenities(),
  };

  if (images && images.length > 0) body.images = images;
  if (isDraft) body.published = false;
  else body.published = true;

  // Clean undefined values
  Object.keys(body).forEach((k) => { if (body[k] === undefined) delete body[k]; });
  // Clean lat/lng if NaN
  if (body.latitude === undefined || isNaN(body.latitude)) delete body.latitude;
  if (body.longitude === undefined || isNaN(body.longitude)) delete body.longitude;

  return body;
}

function getCheckedAmenities() {
  const amenities = [];
  document.querySelectorAll("#amenitiesGrid input[type=checkbox]:checked").forEach((cb) => amenities.push(cb.value));
  return amenities;
}

// =====================================================
// OVERLAY
// =====================================================

function showOverlay(title, desc) {
  DOM.submitTitle.textContent = title;
  DOM.submitDesc.textContent = desc;
  DOM.submitIcon.className = "fa-solid fa-spinner fa-spin";
  DOM.submitIcon.style.color = "#60a5fa";
  DOM.submitOverlay.classList.add("show");
}

function showOverlaySuccess(msg) {
  DOM.submitIcon.className = "fa-solid fa-circle-check";
  DOM.submitIcon.style.color = "#22c55e";
  DOM.submitTitle.textContent = msg;
  DOM.submitDesc.textContent = "Redirecting to dashboard...";
}

function hideOverlay() {
  DOM.submitOverlay.classList.remove("show");
}

// =====================================================
// TOAST
// =====================================================

function showToast(msg, type = "info", dur = 3500) {
  const tc = DOM.toastContainer;
  if (!tc) return;
  const icons = { success: "fa-circle-check", error: "fa-circle-exclamation", info: "fa-circle-info" };
  const t = document.createElement("div");
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i> ${msg}`;
  tc.appendChild(t);
  setTimeout(() => { t.classList.add("toast-leaving"); setTimeout(() => t.remove(), 300); }, dur);
}

window.showToast = showToast;

// =====================================================
// WIZARD NAVIGATION
// =====================================================

let currentStep = 1;
const TOTAL_STEPS = 8;

function showStep(step) {
  currentStep = Math.max(1, Math.min(step, TOTAL_STEPS));
  document.querySelectorAll(".step-panel").forEach((el, i) => {
    el.classList.toggle("active", i + 1 === currentStep);
  });
  document.querySelectorAll(".wizard-step-indicator").forEach((el, i) => {
    const idx = i + 1;
    el.classList.toggle("active", idx === currentStep);
    el.classList.toggle("completed", idx < currentStep);
  });
  document.querySelectorAll(".wizard-connector").forEach((el, i) => {
    el.classList.toggle("completed", i + 1 < currentStep);
  });
  updateProgress();
}

function nextStep() {
  if (currentStep < TOTAL_STEPS) showStep(currentStep + 1);
}

function previousStep() {
  if (currentStep > 1) showStep(currentStep - 1);
}

function updateProgress() {
  const pct = Math.round(((currentStep - 1) / (TOTAL_STEPS - 1)) * 100);
  const stepNames = [
    "Property Information", "Location", "Pricing", "Accommodation",
    "Amenities", "House Rules", "Images", "Publish"
  ];
  const stepDisplay = document.getElementById("currentStepDisplay");
  const nameDisplay = document.getElementById("stepNameDisplay");
  const pctDisplay = document.getElementById("progressPct");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");
  if (stepDisplay) stepDisplay.textContent = currentStep;
  if (nameDisplay) nameDisplay.textContent = stepNames[currentStep - 1];
  if (pctDisplay) pctDisplay.textContent = pct + "%";
  if (prevBtn) prevBtn.disabled = currentStep === 1;
  if (nextBtn) nextBtn.style.display = currentStep === TOTAL_STEPS ? "none" : "";
}

// Wire up wizard buttons (module script runs after DOM ready)
document.getElementById("prevBtn")?.addEventListener("click", previousStep);
document.getElementById("nextBtn")?.addEventListener("click", nextStep);
showStep(1);

console.log("✅ Add Property Page Loaded");

