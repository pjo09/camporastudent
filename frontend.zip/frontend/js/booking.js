// ======================================================
// CAMPORA BOOKING SYSTEM
// ======================================================

import { getToken, getUser, protectPageByRole } from "./session.js";

const API = "http://localhost:5000/api";

// ==========================================
// AUTH CHECK - only students can book
// ==========================================

const user = protectPageByRole(["student"]);
if (!user) {
    // redirect already handled by protectPageByRole
}

const token = getToken();
const params = new URLSearchParams(window.location.search);
const propertyId = params.get("id");

function $(id) {
    return document.getElementById(id);
}

// ==========================================
// VALIDATE PROPERTY ID
// ==========================================

if (!propertyId) {
    alert("No property selected.");
    window.location.href = "dashboard.html";
}

// ==========================================
// LOAD PAGE
// ==========================================

window.addEventListener("DOMContentLoaded", () => {
    loadStudent();
    loadProperty();
});

// ==========================================
// STUDENT INFO
// ==========================================

function loadStudent() {
    if (!user) return;

    const nameField = $("studentName");
    const emailField = $("studentEmail");

    if (nameField) nameField.value = user.name || "";
    if (emailField) emailField.value = user.email || "";
}

// ==========================================
// LOAD PROPERTY
// ==========================================

async function loadProperty() {
    try {
        const res = await fetch(`${API}/properties/${propertyId}`);
        const data = await res.json();

        if (!res.ok) {
            throw new Error(data.message || "Unable to load property.");
        }

        const property = data.property || data;
        renderProperty(property);

    } catch (err) {
        console.error("Load Property Error:", err);
        alert("Unable to load property details.");
        window.location.href = "dashboard.html";
    }
}

// ==========================================
// RENDER PROPERTY SUMMARY
// ==========================================

function renderProperty(property) {
    const propertyName = property.propertyName || property.title || "Campora Property";
    const rent = property.rent || property.price || 0;
    const deposit = property.deposit || 0;
    const city = property.city || "";
    const state = property.state || "";
    const location = city + (state ? ", " + state : "");

    const imagePath = property.images?.length ? property.images[0] : "";

    // Property title
    const titleEl = $("propertyTitle");
    if (titleEl) titleEl.innerText = propertyName;

    // Location
    const locEl = $("propertyLocation");
    if (locEl) locEl.innerText = location || "Location not specified";

    // Price
    const priceEl = $("propertyPrice");
    if (priceEl) priceEl.innerText = rent;

    // Deposit
    const depositEl = $("deposit");
    if (depositEl) depositEl.innerText = "\u20B9" + deposit;

    // Image
    const imageEl = $("propertyImage");
    if (imageEl) {
        imageEl.src = imagePath
            ? (imagePath.startsWith("http")
                ? imagePath
                : `${API.replace("/api", "")}/${imagePath.replace(/^\/+/, "")}`)
            : "https://placehold.co/700x450?text=Campora";
    }

    // Total amount
    const total = Number(rent) + 1000 + Number(deposit);
    const totalEl = $("totalAmount");
    if (totalEl) totalEl.innerText = "\u20B9" + total;
}

// ==========================================
// CHECK EXISTING BOOKING (duplicate prevention)
// ==========================================

async function checkExistingBooking() {
    if (!token || !user) return false;
    try {
        const res = await fetch(
            `${API}/bookings/check?propertyId=${propertyId}&userId=${user.id || user._id}`,
            { headers: { Authorization: `Bearer ${token}` } }
        );
        const data = await res.json();
        return data.exists;
    } catch (err) {
        return false;
    }
}

// ==========================================
// SUBMIT BOOKING
// ==========================================

const bookingForm = $("bookingForm");

if (bookingForm) {
    bookingForm.addEventListener("submit", submitBooking);
}

async function submitBooking(e) {
    e.preventDefault();

    const button = bookingForm.querySelector("button[type='submit']");
    if (!button) return;

    // ==========================================
    // INPUT VALIDATION
    // ==========================================

    const moveInDate = $("moveInDate")?.value;
    const duration = $("duration")?.value;
    const specialRequestField = $("specialRequest");
    const specialRequest = specialRequestField ? specialRequestField.value.trim() : "";

    if (!moveInDate) {
        alert("Please select a move-in date.");
        return;
    }

    // Validate move-in date is not in the past
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const selectedDate = new Date(moveInDate);
    if (selectedDate < today) {
        alert("Move-in date cannot be in the past.");
        return;
    }

    if (!duration) {
        alert("Please select a duration.");
        return;
    }

    if (specialRequest.length > 500) {
        alert("Special request must be under 500 characters.");
        return;
    }

    // ==========================================
    // CHECK DUPLICATE BOOKING
    // ==========================================

    try {
        const checkRes = await fetch(
            `${API}/bookings/check?propertyId=${propertyId}&userId=${user.id || user._id}`,
            { headers: { Authorization: `Bearer ${token}` } }
        );
        const checkData = await checkRes.json();
        if (checkData.exists) {
            alert("You already have a booking for this property. Please check your dashboard.");
            window.location.href = "dashboard.html";
            return;
        }
    } catch (err) {
        // Continue even if check fails
    }

    // Disable button
    button.disabled = true;
    button.innerText = "Creating Booking...";

    try {
        const body = {
            propertyId,
            userId: user.id || user._id,
            userName: user.name,
            userEmail: user.email,
            moveInDate,
            duration,
            specialRequest
        };

        const res = await fetch(`${API}/bookings`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify(body)
        });

        const data = await res.json();

        if (!res.ok || !data.success) {
            throw new Error(data.message || "Booking failed.");
        }

        alert("Booking created successfully!");

        // Redirect to dashboard or payment
        const bookingId = data.booking?._id || data.booking?.id;
        if (bookingId) {
            window.location.href = `payment.html?id=${bookingId}`;
        } else {
            window.location.href = "dashboard.html";
        }

    } catch (err) {
        console.error("Booking Error:", err);
        alert(err.message || "Unable to create booking. Please try again.");
    } finally {
        button.disabled = false;
        button.innerText = "Proceed to Payment";
    }
}

