// =====================================================
// CAMPORA PAYMENT
// =====================================================

const API = "http://localhost:5000/api";

const params = new URLSearchParams(window.location.search);

const bookingId = params.get("id");

const token = localStorage.getItem("camporaToken");

const user = JSON.parse(

localStorage.getItem("camporaUser")

);

function $(id){

return document.getElementById(id);

}

if(!token || !user){

window.location.href="login.html";

}
// =====================================================
// LOAD PAGE
// =====================================================

window.addEventListener("DOMContentLoaded",()=>{

loadBooking();

setupCardFormatting();

});
// =====================================================
// LOAD BOOKING
// =====================================================

let bookingData=null;

async function loadBooking(){

try{

const response=await fetch(

`${API}/bookings/${bookingId}`,

{

headers:{

Authorization:`Bearer ${token}`

}

}

);

const data=await response.json();

bookingData=data.booking || data;

renderBooking();

}

catch(err){

console.log(err);

alert("Unable to load booking.");

}

}
// =====================================================
// RENDER BOOKING
// =====================================================

function renderBooking(){

const property=bookingData.property;

$("propertyTitle").innerText=

property.title;

$("propertyLocation").innerText=

property.city+", "+property.state;

$("propertyImage").src=

property.images?.length

?property.images[0]

:"./images/property-placeholder.jpg";

$("amount").innerText=

property.price;

$("deposit").innerText=

"₹"+(property.deposit||0);

const total=

Number(property.price)

+1000

+Number(property.deposit||0);

$("total").innerText=

"₹"+total;

}
// =====================================================
// CARD FORMATTING
// =====================================================

function setupCardFormatting(){

const card=$("cardNumber");

card.addEventListener("input",()=>{

let value=

card.value.replace(/\D/g,"");

value=value.match(/.{1,4}/g);

card.value=value

?value.join(" ")

:"";

});

$("expiry").addEventListener("input",e=>{

let value=

e.target.value.replace(/\D/g,"");

if(value.length>=3){

value=value.substring(0,2)

+"/"+

value.substring(2,4);

}

e.target.value=value;

});

}
// =====================================================
// PAYMENT
// =====================================================

$("paymentForm").addEventListener(

"submit",

payNow

);

async function payNow(e){

e.preventDefault();

const button=document.querySelector(".pay-btn");

button.disabled=true;

button.innerText="Processing Payment...";

try{

await fakePayment();

await updatePaymentStatus();

window.location.href=

"success.html?id="+bookingId;

}

catch(err){

alert(err.message);

}

finally{

button.disabled=false;

button.innerText="Pay Securely";

}

}
// =====================================================
// DEMO PAYMENT
// =====================================================

function fakePayment(){

return new Promise(resolve=>{

setTimeout(()=>{

resolve();

},2500);

});

}
// =====================================================
// UPDATE PAYMENT
// =====================================================

async function updatePaymentStatus(){

await fetch(

`${API}/payments`,

{

method:"POST",

headers:{

"Content-Type":"application/json",

Authorization:`Bearer ${token}`

},

body:JSON.stringify({

bookingId,

status:"Paid"

})

}

);

}
// =====================================================
// COUPON
// =====================================================

$("coupon").addEventListener(

"change",

()=>{

const code=

$("coupon").value.trim().toUpperCase();

if(code==="CAMPORA100"){

alert(

"Coupon Applied"

);

}

});