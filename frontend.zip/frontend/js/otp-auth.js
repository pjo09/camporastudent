// =======================================
// CAMPORA OTP AUTH
// =======================================

const API = "http://localhost:5000/api/otp";

export async function sendOTP(name, email) {

    const response = await fetch(`${API}/send`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            name,
            email
        })

    });

    return await response.json();

}

export async function verifyOTP(name, email, code, password) {

    const response = await fetch(`${API}/verify`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            name,
            email,
            code,
            password

        })

    });

    return await response.json();

}

export function saveLogin(data){

    localStorage.setItem("camporatoken", data.token);

    localStorage.setItem("camporauser", JSON.stringify(data.user));

}

export function getUser(){

    return JSON.parse(localStorage.getItem("camporauser"));

}

export function logout(){

    localStorage.removeItem("camporatoken");

    localStorage.removeItem("camporauser");

}