// =====================================================
// CAMPORA SUCCESS PAGE
// =====================================================

const API = "http://localhost:5000/api";

const params = new URLSearchParams(window.location.search);

const bookingId = params.get("id");

const token = localStorage.getItem("camporaToken");

function $(id){

    return document.getElementById(id);

}

window.addEventListener("DOMContentLoaded",()=>{

    loadBooking();

});
// =====================================================
// LOAD BOOKING
// =====================================================

async function loadBooking(){

    try{

        const response = await fetch(

            `${API}/bookings/${bookingId}`,

            {

                headers:{

                    Authorization:`Bearer ${token}`

                }

            }

        );

        const data = await response.json();

        const booking = data.booking || data;

        renderBooking(booking);

    }

    catch(err){

        console.log(err);

        alert("Unable to load booking.");

    }

}
// =====================================================
// SHOW BOOKING
// =====================================================

function renderBooking(booking){

    $("bookingId").innerText = booking._id;

    $("propertyName").innerText =

        booking.property.title;

    const total =

        Number(booking.property.price)

        +

        Number(booking.property.deposit || 0)

        +

        1000;

    $("paidAmount").innerText =

        "₹"+total.toLocaleString();

}
// =====================================================
// DOWNLOAD INVOICE
// =====================================================

$("downloadInvoice").addEventListener(

"click",

downloadInvoice

);

function downloadInvoice(e){

    e.preventDefault();

    const invoice = `

==============================

CAMPORA INVOICE

==============================

Booking ID :

${$("bookingId").innerText}

Property :

${$("propertyName").innerText}

Amount Paid :

${$("paidAmount").innerText}

Status :

PAID

Thank you for choosing Campora.

`;

    const blob =

    new Blob(

        [invoice],

        {type:"text/plain"}

    );

    const url=

    URL.createObjectURL(blob);

    const a=document.createElement("a");

    a.href=url;

    a.download="Campora-Invoice.txt";

    a.click();

    URL.revokeObjectURL(url);

}
// =====================================================
// UPDATE DASHBOARD COUNTS
// =====================================================

let completed =

Number(

localStorage.getItem(

"completedBookings"

)||0

);

completed++;

localStorage.setItem(

"completedBookings",

completed

);
// =====================================================
// SIMPLE CONFETTI
// =====================================================

createConfetti();

function createConfetti(){

    for(let i=0;i<120;i++){

        const confetti=document.createElement("div");

        confetti.className="confetti";

        confetti.style.left=Math.random()*100+"vw";

        confetti.style.animationDelay=

        Math.random()*2+"s";

        confetti.style.animationDuration=

        3+Math.random()*3+"s";

        confetti.style.background=

        [

        "#2563eb",

        "#22c55e",

        "#f59e0b",

        "#7c3aed",

        "#ec4899"

        ][

        Math.floor(Math.random()*5)

        ];

        document.body.appendChild(confetti);

    }

}