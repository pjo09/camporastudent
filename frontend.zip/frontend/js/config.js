// =====================================================
// CAMPORA FRONTEND CONFIGURATION
// Change API_BASE in production
// =====================================================

const CONFIG = {
    // Backend API base URL
    // For local development:
    API_BASE: "http://localhost:5000",

    // For production, uncomment and update:
    // API_BASE: "https://api.campora.in",

    // Timeouts
    REQUEST_TIMEOUT: 15000, // 15 seconds
    UPLOAD_TIMEOUT: 60000,  // 60 seconds for uploads

    // Pagination defaults
    DEFAULT_PAGE_SIZE: 12,

    // Feature flags
    ENABLE_ANALYTICS: true,
    ENABLE_NOTIFICATIONS: true,
    ENABLE_REALTIME_CHAT: false,   // Future feature
    ENABLE_PWA: false              // Future feature
};

// Make CONFIG globally available
if (typeof window !== "undefined") {
    window.__CONFIG = CONFIG;
    window.__API = CONFIG.API_BASE;
}

// Also set API constant used across all JS files
const API = CONFIG.API_BASE;

export default CONFIG;
export { API };

