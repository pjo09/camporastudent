// ===========================================
// CAMPORA OWNER DASHBOARD
// Production-quality rewrite
// ===========================================

import { getToken, getUser, protectPageByRole, logout as sessionLogout } from "./session.js";

const API = "http://localhost:5000/api";

// ===========================================
// AUTH CHECK - only owners allowed
// ===========================================

const user = protectPageByRole(["owner"]);
if (!user) {
    // redirect already handled by protectPageByRole
}

const token = getToken();

// ===========================================
// DOM CACHE
// ===========================================

const $ = (id) => document.getElementById(id);


// ===========================================
// TOAST
// ===========================================

function showToast(message, type = "info", duration = 4000) {
  const container = document.getElementById("toastContainer");
  if (!container) {
    // Create toast container if not present
    const newContainer = document.createElement("div");
    newContainer.id = "toastContainer";
    newContainer.className = "toast-container";
    newContainer.setAttribute("aria-live", "polite");
    newContainer.setAttribute("aria-atomic", "true");
    document.body.appendChild(newContainer);
  }
  const targetContainer = container || document.getElementById("toastContainer");

  const icons = {
    success: "fa-solid fa-circle-check",
    error: "fa-solid fa-circle-exclamation",
    info: "fa-solid fa-circle-info",
  };

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.setAttribute("role", "alert");
  toast.innerHTML = `<i class="${icons[type] || icons.info}"></i> ${message}`;
  targetContainer.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("toast-leaving");
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ===========================================
// API HELPER
// ===========================================

async function apiFetch(endpoint, opts = {}) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API}${endpoint}`, { ...opts, headers });
  const data = await res.json();
  if (!res.ok || !data.success)
    throw new Error(data.message || `Request failed (${res.status})`);
  return data;
}

// ===========================================
// START
// ===========================================

document.addEventListener("DOMContentLoaded", () => {
  loadOwner();
  loadDashboardStats();
  loadProperties();

  // Logout handler
  if (DOM.logoutBtn) {
    DOM.logoutBtn.addEventListener("click", () => {
      sessionLogout();
      window.location.href = "login.html";
    });
  }

  // Retry button
  if (DOM.retryBtn) {
    DOM.retryBtn.addEventListener("click", () => {
      if (DOM.dashboardError) DOM.dashboardError.style.display = "none";
      loadDashboardStats();
      loadProperties();
    });
  }
});

// ===========================================
// OWNER INFO
// ===========================================

function loadOwner() {
  if (!user) return;

  if (DOM.ownerName) {
    DOM.ownerName.textContent = user.name || "Owner";
  }

  if (DOM.ownerAvatar) {
    DOM.ownerAvatar.textContent = (user.name || "O").charAt(0).toUpperCase();
  }
}

// ===========================================
// LOAD DASHBOARD STATS
// ===========================================

async function loadDashboardStats() {
  // Show skeleton loading
  if (DOM.statsSkeleton) DOM.statsSkeleton.style.display = "grid";
  if (DOM.statsGrid) {
    const statValues = DOM.statsGrid.querySelectorAll(".stat-value, .stat-card h2");
    statValues.forEach((el) => {
      el.textContent = "---";
    });
  }
  if (DOM.dashboardError) DOM.dashboardError.style.display = "none";

  try {
    const data = await apiFetch("/owner/dashboard");
    const statistics = data.statistics || {};

    const totalBeds = Number(statistics.totalBeds) || 0;
    const occupiedBeds = Number(statistics.occupiedBeds) || 0;
    const occupancy = totalBeds
      ? Math.round((occupiedBeds / totalBeds) * 100)
      : 0;

    if (DOM.totalProperties)
      DOM.totalProperties.textContent = Number(statistics.totalProperties) || 0;
    if (DOM.totalBookings)
      DOM.totalBookings.textContent = Number(statistics.totalBookings) || 0;
    if (DOM.occupancy) DOM.occupancy.textContent = `${occupancy}%`;
    if (DOM.monthlyRevenue)
      DOM.monthlyRevenue.textContent = `₹${Number(statistics.earnings || statistics.totalRevenue || 0).toLocaleString()}`;

    if (DOM.statsSkeleton) DOM.statsSkeleton.style.display = "none";
  } catch (err) {
    console.error("Owner Dashboard Stats Error:", err);
    if (DOM.statsSkeleton) DOM.statsSkeleton.style.display = "none";
    if (DOM.dashboardError) {
      DOM.dashboardError.style.display = "block";
      DOM.dashboardError.querySelector("p").textContent =
        "Unable to load dashboard statistics. " + err.message;
    }
    showToast("Failed to load dashboard statistics", "error");
  }
}

// ===========================================
// LOAD PROPERTIES
// ===========================================

async function loadProperties() {
  if (!DOM.propertyGrid) return;

  DOM.propertyGrid.innerHTML = `
    <div class="loading" style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#94a3b8">
      <i class="fa-solid fa-spinner fa-spin" style="font-size:32px;margin-bottom:16px;display:block"></i>
      Loading Properties...
    </div>
  `;

  try {
    const data = await apiFetch("/owner/properties");
    DOM.propertyGrid.innerHTML = "";

    const properties = data.properties || [];

    if (properties.length === 0) {
      DOM.propertyGrid.innerHTML = `
        <div class="loading" style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#94a3b8">
          <i class="fa-solid fa-house" style="font-size:48px;margin-bottom:16px;display:block;opacity:0.5"></i>
          <h3 style="color:#fff;margin-bottom:8px;font-size:22px">No Properties Yet</h3>
          <p>Add your first property to get started.</p>
          <a href="add-property.html" class="primary-btn" style="display:inline-block;margin-top:20px;padding:14px 32px;background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;border:none;border-radius:16px;font-weight:700;text-decoration:none">+ Add New Property</a>
        </div>
      `;
      return;
    }

    properties.forEach((property) => {
      const propertyName =
        property.propertyName || property.title || "Untitled Property";
      const rent = property.rent || property.price || 0;
      const rating = property.averageRating || property.rating || "New";
      const status = property.status || "pending";
      const statusColor =
        status === "approved"
          ? "#22c55e"
          : status === "rejected"
          ? "#ef4444"
          : "#f59e0b";
      const imagePath =
        property.images && property.images.length ? property.images[0] : "";
      const image = imagePath
        ? imagePath.startsWith("http")
          ? imagePath
          : `${API.replace("/api", "")}/${imagePath.replace(/^\/+/, "")}`
        : "https://placehold.co/700x450?text=Campora";

      const card = document.createElement("div");
      card.className = "property-card";
      card.style.animation = "fadeUp 0.4s ease";
      card.innerHTML = `
        <img class="property-image" src="${image}" alt="${propertyName}" loading="lazy" onerror="this.src='https://placehold.co/700x450?text=Campora'">
        <div class="property-body">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3 style="font-size:18px;font-weight:700">${propertyName}</h3>
            <span style="font-size:12px;font-weight:600;color:${statusColor};background:${statusColor}22;padding:4px 10px;border-radius:999px;text-transform:capitalize">${status}</span>
          </div>
          <p style="color:#94a3b8;margin-top:8px">📍 ${property.city || "-"}${property.state ? ", " + property.state : ""}</p>
          <p style="color:#60a5fa;font-weight:700;font-size:20px;margin-top:8px">₹${Number(rent).toLocaleString()}<span style="color:#94a3b8;font-weight:400;font-size:14px">/month</span></p>
          <p style="color:#94a3b8;font-size:14px;margin-top:4px">
            ⭐ ${rating} &bull; 🛏️ ${property.availableBeds || 0}/${property.totalBeds || 0} beds
          </p>
          <div class="property-actions" style="display:flex;gap:10px;margin-top:16px">
            <button class="edit-btn" onclick="window.editProperty('${property._id}')" style="flex:1;padding:10px;border:none;border-radius:12px;background:rgba(37,99,235,.15);color:#60a5fa;font-weight:600;cursor:pointer;transition:.3s">Edit</button>
            <button class="delete-btn" onclick="window.deleteProperty('${property._id}')" style="flex:1;padding:10px;border:none;border-radius:12px;background:rgba(239,68,68,.15);color:#ef4444;font-weight:600;cursor:pointer;transition:.3s">Delete</button>
            <button class="view-btn" onclick="window.viewOwnerProperty('${property._id}')" style="padding:10px 14px;border:none;border-radius:12px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;transition:.3s"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
      `;
      DOM.propertyGrid.appendChild(card);
    });
  } catch (err) {
    console.error("Owner Properties Error:", err);
    DOM.propertyGrid.innerHTML = `
      <div class="loading" style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#94a3b8">
        <i class="fa-solid fa-exclamation-triangle" style="font-size:48px;margin-bottom:16px;display:block;color:#ef4444"></i>
        <h3 style="color:#fca5a5;margin-bottom:8px;font-size:22px">Failed to Load Properties</h3>
        <p style="color:#94a3b8">${err.message}</p>
        <button onclick="document.location.reload()" style="margin-top:20px;padding:14px 32px;background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;border:none;border-radius:16px;font-weight:700;cursor:pointer">Try Again</button>
      </div>
    `;
    showToast("Failed to load properties: " + err.message, "error");
  }
}

// ===========================================
// DELETE PROPERTY (global)
// ===========================================

window.deleteProperty = async function (id) {
  if (!confirm("Are you sure you want to delete this property? This action cannot be undone."))
    return;

  const btn = event?.target;
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Deleting...";
  }

  try {
    await apiFetch(`/properties/${id}`, { method: "DELETE" });
    showToast("Property deleted successfully", "success");
    loadProperties();
  } catch (err) {
    showToast("Unable to delete property: " + err.message, "error");
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Delete";
    }
  }
};

// ===========================================
// EDIT PROPERTY (global)
// ===========================================

window.editProperty = function (id) {
  window.location.href = `add-property.html?id=${id}`;
};

// ===========================================
// VIEW PROPERTY (global)
// ===========================================

window.viewOwnerProperty = function (id) {
  window.open(`../property-details.html?id=${id}`, "_blank");
};

// ===========================================
// KEYBOARD NAVIGATION
// ===========================================

document.querySelectorAll(".nav-item, .bottom-nav-item").forEach((item) => {
  item.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      item.click();
    }
  });
});

// ===========================================
// SIDEBAR TOGGLE (if menuBtn exists)
// ===========================================

const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");
const sidebarBackdrop = document.getElementById("sidebarBackdrop");

if (menuBtn && sidebar) {
  menuBtn.addEventListener("click", () => {
    sidebar.classList.toggle("active");
    menuBtn.setAttribute(
      "aria-expanded",
      sidebar.classList.contains("active") ? "true" : "false"
    );
    if (sidebarBackdrop) {
      sidebarBackdrop.hidden = !sidebar.classList.contains("active");
    }
  });

  if (sidebarBackdrop) {
    sidebarBackdrop.addEventListener("click", () => {
      sidebar.classList.remove("active");
      menuBtn.setAttribute("aria-expanded", "false");
      sidebarBackdrop.hidden = true;
    });
  }
}

console.log("✅ Campora Owner Dashboard V2 initialised");

