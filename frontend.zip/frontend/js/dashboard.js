// ==========================================
// CAMPORA DASHBOARD
// ==========================================

const API_BASE = "http://localhost:5000/api";

// ------------------------------------------
// CHECK LOGIN
// ------------------------------------------

const token = localStorage.getItem("camporatoken");
const user = JSON.parse(localStorage.getItem("camporauser"));

if (!token || !user) {

    window.location.href = "login.html";

}

// ------------------------------------------
// SHOW USER
// ------------------------------------------

const welcomeText = document.getElementById("welcomeText");

if (welcomeText) {

    welcomeText.innerHTML =
        `Welcome, ${user.name} 👋`;

}

// ------------------------------------------
// PROFILE NAME
// ------------------------------------------

const profileName = document.getElementById("profileName");

if (profileName) {

    profileName.innerText = user.name;

}

const profileEmail = document.getElementById("profileEmail");

if (profileEmail) {

    profileEmail.innerText = user.email;

}

// ------------------------------------------
// LOGOUT
// ------------------------------------------

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {

    logoutBtn.addEventListener("click", () => {

        localStorage.removeItem("camporatoken");

        localStorage.removeItem("camporauser");

        window.location.href = "login.html";

    });

}

// ------------------------------------------
// LOADER
// ------------------------------------------

window.addEventListener("load", () => {

    const loader = document.querySelector(".loader");

    if (loader) {

        loader.classList.add("hide");

    }

});

// ------------------------------------------
// TOAST
// ------------------------------------------

function showToast(message, type = "success") {

    const container =
        document.querySelector(".toast-container");

    if (!container) return;

    const toast =
        document.createElement("div");

    toast.className =
        `toast ${type}`;

    toast.innerHTML = `

        <h4>${type.toUpperCase()}</h4>

        <p>${message}</p>

    `;

    container.appendChild(toast);

    setTimeout(() => {

        toast.remove();

    }, 3000);

}

console.log("✅ Dashboard Loaded");
